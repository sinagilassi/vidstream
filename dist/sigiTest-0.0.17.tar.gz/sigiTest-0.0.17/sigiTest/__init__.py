from sigiTest.myfun import fun1
