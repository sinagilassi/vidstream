from sigiTest.docs.doc_fun1 import dFun1_1
