
from sigiTest.core.core_fun2 import cFun2_1


def cFun1_1():
    return "cFun1_1 * " + cFun2_1()


def cFun1_2():
    return "cFun1_2"
