from sigiTest.core.core_fun2 import cFun2_2
