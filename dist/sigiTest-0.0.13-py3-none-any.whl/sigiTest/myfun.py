def fun1():
    return 1
