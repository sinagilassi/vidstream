from .docs import dFun1_1


def fun1():
    return dFun1_1()
